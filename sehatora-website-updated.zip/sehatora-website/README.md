# Sehatora Dubai – Website package

Know | Care | Live Better. A health guidance website for Dubai.

## What's in this folder

| File / folder | What it is |
|---|---|
| `index.html` | **The complete website in one file.** Open it in any browser, or upload it to hosting. All images are built in. |
| `_headers`, `robots.txt` | Settings for Cloudflare Pages (security headers) and search engines. |
| `source/app.js` | All website scripts, as a separate file for developers. |
| `source/styles.css` | All website styles, as a separate file for developers. |
| `source/admin.js`, `source/admin.css` | Only the admin panel code and styles. |
| `assets/images/` | All 32 website photos as normal image files (hero, services, guides, products). |
| `assets/logo/` | Sehatora logo: normal and light version (for dark backgrounds), transparent PNG. |
| `samples/meal-plan-sample.pdf` | A sample of the PDF the protein tool creates. |

## Pages
Home · Services (6) · Protein & meal planner (7-day plan with a 11-page PDF report) · Guides · Blog (30 guides) · Product label guide (6 products) · Doctors & facilities · Book appointment · Nutrition consult · My Health dashboard · About · Contact · Admin (`#/admin`)

## Protein & meal planner
- **34 foods** across 4 diet levels (vegan, vegetarian, vegetarian + eggs, non-vegetarian), including labneh, hummus, quinoa, sweet potato, spinach, salmon, walnuts, turkey and prawns, each with iron, calcium, vitamin D, B12 and omega-3 values.
- **A real 7-day rotation**, not one day repeated seven times — each day is planned separately with its own candidate menus, and a day's dishes try not to repeat the previous day's main ingredient.
- **Micronutrient tracking** against daily reference intakes (iron, calcium, vitamin D, B12, omega-3), shown per day and as a weekly average, with bars flagged when a nutrient falls under 60% of target.
- **A real weekly shopping list**, combined from the 7 distinct days actually generated, not a single day's list multiplied by seven.
- **An 11-page PDF report**: a cover page, daily targets with micronutrient reference intakes, a week-at-a-glance table, one page per day with that day's meals and micronutrient bars, a weekly shopping list, and habits/safety notes — built entirely in the browser with no external libraries.

## Put it online (Cloudflare Pages)
1. Go to dash.cloudflare.com, then Workers & Pages, then Create, then Pages, then Upload assets.
2. Upload this folder (or just `index.html`, `_headers` and `robots.txt`).
3. Deploy. Add your own domain under Custom domains.

## What works where

| Feature | Inside Claude (live link) | Normal hosting (e.g. Cloudflare) |
|---|---|---|
| All pages, design, sliders, announcement bar, social icons | Yes | Yes |
| Protein planner and meal plan PDF | Yes | Yes |
| AI Health Guide questions, next steps, emergency cards | Yes | Yes |
| My Health dashboard | Saved privately to the account | Saved in the visitor's own browser |
| AI replies (guide note, follow-ups, nutrition consult chat) | Yes | Basic built-in answers only |
| Admin panel, analytics, saved doctors, request records | Yes | Needs a backend |

To run the AI and admin features on normal hosting, connect a database (for example Supabase or Firebase) and the Claude API. In the code, the places to connect are `ADM.db` / `HS` (database) and `window.claude.use("sample")` (AI).

## Before going live
- Add your real Instagram, Facebook, Pinterest, TikTok and YouTube links (search for `instagram.com` in `index.html`).
- Add WhatsApp and email for appointment requests: `const CONFIG={ whatsapp:"", email:"" }`.
- Confirm the UAE mental health support line number (800 HOPE / 800 4673) on an official source.
- Replace AI-generated product pack photos with official pack shots if label text must be exact.

General education only, not medical advice. Emergency in the UAE: call 998.
