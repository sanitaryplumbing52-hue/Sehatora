/* Sehatora Dubai – Admin panel code (extracted from sehatpath-dubai.html).
   It runs inside the website file: it uses the site data (DOCTORS, FACS, POSTS, SPECS),
   helpers ($, ic, route) and the Claude artifact db/user capabilities. */
/* =====================================================================
   ADMIN DATA LAYER: shared records, per-viewer logs, public overlay
   ===================================================================== */
const ADM={db:null,user:null,uid:null,isAdmin:false,ready:null,rec:{doctors:{},facilities:{},articles:{},knowledge:{},aireview:{},reqstatus:{}},own:{events:[],ailog:{sessions:[],unsafe:[]},requests:[],member:null},q:{},tab:"overview",sel:null};
const ADM_LIC=[["unverified","Not verified"],["pending","Pending review"],["verified","Verified"],["expired","Expired"],["suspended","Suspended"]];
const ADM_ART=[["draft","Draft"],["review","Editorial review"],["medical","Medical review"],["published","Published"]];
const admNow=()=>new Date().toISOString();
const admE=t=>String(t==null?"":t).replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
function admQueue(path,fn){const q=ADM.q[path]||Promise.resolve();ADM.q[path]=q.then(fn).catch(()=>{});return ADM.q[path]}
async function admSet(path,data){if(!ADM.db)return false;try{await admQueue(path,()=>ADM.db.doc(path).set(data));return true}catch(e){return false}}
ADM.ready=(async()=>{
  try{
    if(!(window.claude&&window.claude.use))return;
    const [db,user]=await Promise.all([window.claude.use("db"),window.claude.use("user")]);
    if(!db)return;ADM.db=db;ADM.user=user;ADM.uid=user&&user.id?await user.id():null;
    ADM.isAdmin=user?!!(await user.canEdit().catch(()=>false)):false;
    for(const c of ["doctors","facilities","articles","knowledge"]){try{const s=await db.collection(c).get();s.docs.forEach(d=>{ADM.rec[c][d.id]=d.data()})}catch(e){}}
    if(ADM.uid){
      const get=async p=>{try{const s=await db.doc(p).get();return s.exists?s.data():null}catch(e){return null}};
      const ev=await get("events/"+ADM.uid);ADM.own.events=(ev&&ev.items)||[];
      const al=await get("ailog/"+ADM.uid);ADM.own.ailog={sessions:(al&&al.sessions)||[],unsafe:(al&&al.unsafe)||[]};
      const rq=await get("requests/"+ADM.uid);ADM.own.requests=(rq&&rq.items)||[];
      const mb=await get("members/"+ADM.uid);ADM.own.member=mb||{first:admNow(),saved:[]};
      ADM.own.member.last=admNow();admSet("members/"+ADM.uid,ADM.own.member);
    }
    admApply();
    const h=location.hash;if(/doctor|provider|blog|services|service|book|admin|^#?\/?$/.test(h)||h===""||h==="#/")route();
  }catch(e){}
})();
/* overlay admin records onto the public site data */
function admApply(){
  const R=ADM.rec;
  const put=(arr,rec,map)=>{Object.keys(rec).forEach(id=>{const r=rec[id];if(!r)return;
    let i=id.indexOf("b-")===0?parseInt(id.slice(2)):arr.findIndex(x=>x&&x._id===id);
    const obj=map(r,i>=0?arr[i]:null);
    if(i>=0&&arr[i])Object.assign(arr[i],obj,{_id:id});else{arr.push(Object.assign(obj,{_id:id}))}})};
  put(DOCTORS,R.doctors,r=>({name:r.name,spec:+r.spec,fac:+r.fac,role:r.role||"",insurance:r.insurance||"",langs:r.langs||"",licence:r.licNo||"",url:r.url||"",src:r.src||"",bio:r.bio||"",lic:r.lic||"unverified",licExp:r.licExp||"",_hidden:r.published===false}));
  put(FACS,R.facilities,(r,old)=>({n:r.n,t:r.t||"Clinic",area:r.area||"",u:r.u||"",s:(r.s||[]).map(Number),about:r.about||(old&&old.about)||"",ver:r.ver||"unverified",_hidden:r.published===false}));
  put(POSTS,R.articles,(r,old)=>{const o={t:r.t,c:r.c,m:+r.m||3,b:r.b||(old&&old.b)||"",_hidden:r.status!=="published",seo:r.seo||null};return o});
}
function licBadge(d){const s=d.lic||(d.licence?"unverified":"");if(s==="verified")return `<span class="lic-badge ok">${ic("shield")} DHA licence verified</span>`;return ""}
/* ---------- per-viewer logs (analytics, AI, requests, saves) ---------- */
let admEvTimer=null;
function evLog(type,key,extra){
  if(!ADM.uid&&!ADM.ready)return;
  ADM.own.events.push(Object.assign({t:type,k:String(key==null?"":key).slice(0,120),at:Date.now()},extra||{}));
  if(ADM.own.events.length>600)ADM.own.events=ADM.own.events.slice(-600);
  clearTimeout(admEvTimer);admEvTimer=setTimeout(()=>{if(ADM.uid)admSet("events/"+ADM.uid,{items:ADM.own.events})},2500);
}
function aiLogSession(s){if(!ADM.uid)return;ADM.own.ailog.sessions.push(s);ADM.own.ailog.sessions=ADM.own.ailog.sessions.slice(-200);admSet("ailog/"+ADM.uid,ADM.own.ailog)}
const AI_UNSAFE=[[/\b(you (have|are suffering from|probably have|likely have))\b/i,"Sounds like a diagnosis"],[/\b(diagnos(is|ed) (is|with))\b/i,"Sounds like a diagnosis"],[/\b\d+(\.\d+)?\s?(mg|mcg|ml)\b/i,"Mentions a dose"],[/\btake \d+ (tablets?|pills?|capsules?)\b/i,"Mentions a dose"],[/\b(guarantee|100% cure|cure[sd]? (it|this) completely)\b/i,"Promises a result"]];
function aiCheck(reply,topic,where){if(!reply||!ADM.uid)return;for(const [re,why] of AI_UNSAFE){if(re.test(reply)){ADM.own.ailog.unsafe.push({id:"u"+Date.now().toString(36),at:Date.now(),topic:topic||"",where,why,reply:String(reply).slice(0,900)});ADM.own.ailog.unsafe=ADM.own.ailog.unsafe.slice(-100);admSet("ailog/"+ADM.uid,ADM.own.ailog);return}}}
function memberSaved(){return (ADM.own.member&&ADM.own.member.saved)||[]}
async function toggleSaveDoc(i){if(!ADM.uid)return false;const m=ADM.own.member||(ADM.own.member={first:admNow(),saved:[]});const key=DOCTORS[i]._id||("b-"+i);const s=new Set(m.saved||[]);s.has(key)?s.delete(key):s.add(key);m.saved=[...s];m.last=admNow();await admSet("members/"+ADM.uid,m);return s.has(key)}
const isSavedDoc=i=>memberSaved().includes(DOCTORS[i]._id||("b-"+i));
document.addEventListener("click",async e=>{const b=e.target.closest("[data-save-doc]");if(!b)return;e.preventDefault();
  await ADM.ready;if(!ADM.uid){b.textContent="Sign in to save";return}
  const on=await toggleSaveDoc(+b.dataset.saveDoc);b.textContent=on?"Saved ✓":"Save doctor";b.setAttribute("aria-pressed",String(on));evLog(on?"save":"unsave",b.dataset.saveDoc)});
/* route-level analytics */
let admReadTimer=null;
function admTrack(){
  const h=location.hash.replace(/^#\/?/,""),[p,a]=h.split("/");
  if(p==="doctor")evLog("doctor_view",a);else if(p==="provider")evLog("facility_view",a);
  else if(p==="blog"&&a!==undefined){evLog("article_view",a);clearTimeout(admReadTimer);let done=false;
    const on=()=>{if(done)return;const sc=(scrollY+innerHeight)/document.documentElement.scrollHeight;if(sc>.8){done=true;evLog("article_read",a);removeEventListener("scroll",on)}};addEventListener("scroll",on,{passive:true});admReadTimer=setTimeout(()=>removeEventListener("scroll",on),600000)}
  else if(p==="service")evLog("service_view",a);
  else if(p!=="admin")evLog("page_view",p||"home");
}
addEventListener("hashchange",admTrack);ADM.ready.then(admTrack);
document.addEventListener("change",e=>{if(!e.isTrusted)return;if(e.target&&e.target.id==="spec")evLog("spec_search",e.target.value);if(e.target&&e.target.id==="bSpec")evLog("spec_pick",e.target.value)});
function admKnowledge(){const k=Object.values(ADM.rec.knowledge||{}).filter(x=>x&&x.active!==false);return k.length?"\n\nAPPROVED KNOWLEDGE SOURCES (you may point people to these):\n"+k.map(x=>`- ${x.title}${x.url?" ("+x.url+")":""}`).join("\n"):""}

/* =====================================================================
   ADMIN DASHBOARD UI
   ===================================================================== */
const ADM_TABS=[["overview","Overview","activity"],["doctors","Doctors","user"],["facilities","Facilities","pin"],["articles","Articles","book"],["ai","AI","heart"],["users","Users","shield"],["analytics","Analytics","star"]];
PAGES.admin=()=>`<section class="adm-sec"><div class="adm" id="adm"><aside class="adm-nav" aria-label="Admin sections"><div class="adm-brand">${ic("shield")}<div><b>Sehatora Admin</b><small id="admWho">Checking access…</small></div></div><nav id="admTabs">${ADM_TABS.map(t=>`<button type="button" data-atab="${t[0]}" aria-current="${t[0]===ADM.tab?"page":"false"}">${ic(t[2])}<span>${t[1]}</span><em data-badge="${t[0]}"></em></button>`).join("")}</nav><a class="adm-back" href="#/">← Back to website</a></aside><main class="adm-main" id="admMain"><div class="adm-loading">Loading admin data…</div></main></div><div class="adm-drawer" id="admDrawer" hidden><div class="adm-dr-bg" data-aclose></div><div class="adm-dr" role="dialog" aria-modal="true" aria-labelledby="admDrH"><div class="adm-dr-h"><h2 id="admDrH"></h2><button type="button" class="adm-x" data-aclose aria-label="Close">×</button></div><div class="adm-dr-b" id="admDrB"></div></div></div></section>`;
async function initAdmin(){
  document.body.classList.add("is-admin");
  await ADM.ready;
  const who=$("#admWho");if(!who)return;
  if(!ADM.db){$("#admMain").innerHTML=admLocked("The admin panel needs the shared database. Open this page inside Claude to manage content.");who.textContent="Database not available";return}
  if(!ADM.isAdmin){$("#admMain").innerHTML=admLocked("Only people with edit access to this site can use the admin panel.");who.textContent="View-only access";return}
  who.textContent="Editor access";
  await admLoadAll();admRender();
  $("#admTabs").onclick=e=>{const b=e.target.closest("[data-atab]");if(!b)return;ADM.tab=b.dataset.atab;ADM.sel=null;document.querySelectorAll("[data-atab]").forEach(x=>x.setAttribute("aria-current",String(x===b)));admRender();$("#admMain").scrollTop=0;scrollTo({top:0})};
  $("#admDrawer").onclick=e=>{if(e.target.closest("[data-aclose]"))admClose()};
  document.addEventListener("keydown",admEsc);
}
function admEsc(e){if(e.key==="Escape"&&$("#admDrawer")&&!$("#admDrawer").hidden)admClose()}
addEventListener("hashchange",()=>{if(location.hash.indexOf("#/admin")!==0)document.body.classList.remove("is-admin")});
const admLocked=m=>`<div class="adm-locked">${ic("shield")}<h2>Admins only</h2><p>${m}</p><a class="btn alt" href="#/">Back to website</a></div>`;
const ALL={events:[],sessions:[],unsafe:[],requests:[],members:[]};
async function admLoadAll(){
  const db=ADM.db;ALL.events=[];ALL.sessions=[];ALL.unsafe=[];ALL.requests=[];ALL.members=[];
  const col=async c=>{try{return (await db.collection(c).get()).docs}catch(e){return []}};
  (await col("events")).forEach(d=>{(d.data().items||[]).forEach(x=>ALL.events.push(Object.assign({u:d.id},x)))});
  (await col("ailog")).forEach(d=>{const v=d.data();(v.sessions||[]).forEach(x=>ALL.sessions.push(Object.assign({u:d.id},x)));(v.unsafe||[]).forEach(x=>ALL.unsafe.push(Object.assign({u:d.id},x)))});
  (await col("requests")).forEach(d=>{(d.data().items||[]).forEach(x=>ALL.requests.push(Object.assign({u:d.id},x)))});
  (await col("members")).forEach(d=>ALL.members.push(Object.assign({u:d.id},d.data())));
  for(const c of ["aireview","reqstatus"]){(await col(c)).forEach(d=>{ADM.rec[c][d.id]=d.data()})}
  ALL.sessions.sort((a,b)=>b.at-a.at);ALL.unsafe.sort((a,b)=>b.at-a.at);ALL.requests.sort((a,b)=>b.at-a.at);
}
/* ---------- helpers ---------- */
const admDate=t=>t?new Date(t).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}):"–";
const admTime=t=>t?new Date(t).toLocaleString("en-GB",{day:"numeric",month:"short",hour:"2-digit",minute:"2-digit"}):"–";
const admPill=(v,list,cls)=>{const x=list.find(l=>l[0]===v)||[v,v];return `<span class="apill ${cls||""} s-${admE(v)}">${admE(x[1])}</span>`};
const admDays=(t)=>Math.round((new Date(t)-new Date())/864e5);
function admHead(title,sub,actions){return `<header class="adm-h"><div><h1>${title}</h1>${sub?`<p>${sub}</p>`:""}</div><div class="adm-h-a">${actions||""}</div></header>`}
function admTabsBar(id,list,cur){return `<div class="adm-subtabs" role="tablist">${list.map(l=>`<button type="button" role="tab" data-sub="${id}" data-v="${l[0]}" aria-selected="${l[0]===cur}">${l[1]}${l[2]!==undefined?` <em>${l[2]}</em>`:""}</button>`).join("")}</div>`}
function admOpen(title,html,onReady){$("#admDrH").textContent=title;$("#admDrB").innerHTML=html;$("#admDrawer").hidden=false;document.body.style.overflow="hidden";if(onReady)onReady($("#admDrB"));const f=$("#admDrB").querySelector("input,select,textarea,button");if(f)f.focus({preventScroll:true})}
function admClose(){const d=$("#admDrawer");if(d)d.hidden=true;document.body.style.overflow=""}
function admToast(t){let x=$("#admToast");if(!x){x=document.createElement("div");x.id="admToast";x.className="adm-toast";x.setAttribute("role","status");document.body.appendChild(x)}x.textContent=t;x.classList.add("on");clearTimeout(x._t);x._t=setTimeout(()=>x.classList.remove("on"),2200)}
const admFld=(lab,inner,hint)=>`<label class="afld"><span>${lab}</span>${inner}${hint?`<small>${hint}</small>`:""}</label>`;
const admIn=(id,v,attrs)=>`<input id="${id}" value="${admE(v)}" ${attrs||""}>`;
const admSel=(id,opts,v)=>`<select id="${id}">${opts.map(o=>`<option value="${admE(o[0])}"${String(o[0])===String(v)?" selected":""}>${admE(o[1])}</option>`).join("")}</select>`;
const admVal=id=>{const e=document.getElementById(id);return e?e.value.trim():""};
function admHist(h){return (h&&h.length)?`<ol class="ahist">${h.slice().reverse().map(x=>`<li><b>${admE(x.action)}</b><span>${admTime(x.at)}${x.note?` · ${admE(x.note)}`:""}</span></li>`).join("")}</ol>`:`<p class="note">No history yet.</p>`}
/* ---------- records merged with built-ins ---------- */
function admDoctors(){return DOCTORS.map((d,i)=>{const id=d._id||("b-"+i),r=ADM.rec.doctors[id]||{};return {id,i,d,r,builtin:!d._id||id.indexOf("b-")===0,lic:r.lic||d.lic||"unverified",pub:r.published!==false,exp:r.licExp||d.licExp||""}})}
function admFacs(){return FACS.map((f,i)=>{const id=f._id||("b-"+i),r=ADM.rec.facilities[id]||{};return {id,i,f,r,ver:r.ver||f.ver||"unverified",pub:r.published!==false}})}
function admArts(){return POSTS.map((p,i)=>{const id=p._id||("b-"+i),r=ADM.rec.articles[id]||{};return {id,i,p,r,status:r.status||"published"}})}
/* ---------- render ---------- */
function admRender(){
  const m=$("#admMain");if(!m)return;
  const docs=admDoctors(),arts=admArts(),openEsc=ALL.sessions.filter(s=>["emergency","crisis","urgent"].includes(s.level)&&!(ADM.rec.aireview[s.id]||{}).done).length,openUnsafe=ALL.unsafe.filter(u=>!(ADM.rec.aireview[u.id]||{}).done).length,newReq=ALL.requests.filter(r=>!(ADM.rec.reqstatus[r.id]||{}).status||(ADM.rec.reqstatus[r.id]||{}).status==="new").length;
  const badges={doctors:docs.filter(x=>x.lic==="pending").length,articles:arts.filter(a=>a.status==="review"||a.status==="medical").length,ai:openEsc+openUnsafe,users:newReq};
  document.querySelectorAll("[data-badge]").forEach(b=>{const n=badges[b.dataset.badge]||0;b.textContent=n?String(n):""});
  m.innerHTML=({overview:admOverview,doctors:admDoctorsView,facilities:admFacView,articles:admArtView,ai:admAiView,users:admUsersView,analytics:admAnaView}[ADM.tab]||admOverview)();
  m.querySelectorAll("[data-sub]").forEach(b=>b.onclick=()=>{ADM["sub_"+b.dataset.sub]=b.dataset.v;admRender()});
  m.querySelectorAll("[data-filter]").forEach(i=>i.oninput=()=>{ADM["f_"+i.dataset.filter]=i.value;const pos=i.selectionStart;admRender();const n=document.querySelector(`[data-filter="${i.dataset.filter}"]`);if(n){n.focus();try{n.setSelectionRange(pos,pos)}catch(e){}}});
  m.querySelectorAll("[data-act]").forEach(b=>b.onclick=()=>admAct(b.dataset.act,b.dataset.id,b));
  if(ADM.tab==="overview"||ADM.tab==="analytics"){const h=$("#admDaily");if(h)pdBars(h,admDaily(14),"events",null)}
}
function admKpi(l,v,s,cls){return `<div class="akpi ${cls||""}"><small>${l}</small><b>${v}</b>${s?`<span>${s}</span>`:""}</div>`}
function admDaily(n){const out=[],t=new Date();for(let i=n-1;i>=0;i--){const d=new Date(t);d.setDate(t.getDate()-i);const k=d.toISOString().slice(0,10);out.push({d:k,v:0})}ALL.events.forEach(e=>{const k=new Date(e.at).toISOString().slice(0,10);const o=out.find(x=>x.d===k);if(o)o.v++});return out}
function admOverview(){
  const docs=admDoctors(),facs=admFacs(),arts=admArts();
  const exp=docs.filter(x=>x.exp&&admDays(x.exp)<=60);
  const need=[];
  docs.filter(x=>x.lic==="pending").forEach(x=>need.push(["user",`Licence waiting for verification: ${x.d.name}`,"doctors"]));
  exp.forEach(x=>need.push(["alert",`Licence ${admDays(x.exp)<0?"expired":"expires in "+admDays(x.exp)+" days"}: ${x.d.name}`,"doctors"]));
  arts.filter(a=>a.status==="medical").forEach(a=>need.push(["book",`Needs medical review: ${a.p.t}`,"articles"]));
  arts.filter(a=>a.status==="review").forEach(a=>need.push(["book",`Needs editorial review: ${a.p.t}`,"articles"]));
  ALL.sessions.filter(s=>["emergency","crisis"].includes(s.level)&&!(ADM.rec.aireview[s.id]||{}).done).slice(0,5).forEach(s=>need.push(["alert",`AI escalation (${s.level}) on ${admTime(s.at)}`,"ai"]));
  ALL.unsafe.filter(u=>!(ADM.rec.aireview[u.id]||{}).done).slice(0,5).forEach(u=>need.push(["alert",`Flagged AI reply: ${u.why}`,"ai"]));
  const since=Date.now()-7*864e5,wk=ALL.events.filter(e=>e.at>since);
  return admHead("Overview","Everything that needs attention, and how the site is doing this week.",`<button class="btn alt" type="button" data-act="refresh">Refresh data</button>`)+
  `<div class="akpis">${admKpi("Doctors",docs.length,`${docs.filter(x=>x.lic==="verified").length} verified · ${docs.filter(x=>x.lic==="pending").length} pending`)}${admKpi("Facilities",facs.length,`${facs.filter(x=>x.ver==="verified").length} verified`)}${admKpi("Articles",arts.length,`${arts.filter(a=>a.status!=="published").length} not published`)}${admKpi("Appointment requests",ALL.requests.length,`${ALL.requests.filter(r=>r.at>since).length} this week`)}${admKpi("AI guide sessions",ALL.sessions.length,`${ALL.sessions.filter(s=>["emergency","crisis","urgent"].includes(s.level)).length} escalations`)}${admKpi("Page views, 7 days",wk.filter(e=>/view/.test(e.t)).length,`${new Set(wk.map(e=>e.u)).size} people`)}</div>
  <div class="agrid2"><div class="acard"><div class="acard-h"><h2>Needs attention</h2><span class="note">${need.length} ${need.length===1?"item":"items"}</span></div>${need.length?`<ul class="aneed">${need.slice(0,12).map(n=>`<li><i>${ic(n[0])}</i><span>${admE(n[1])}</span><button type="button" class="alink" data-act="goto" data-id="${n[2]}">Open</button></li>`).join("")}</ul>`:`<p class="aempty">${ic("check")} All clear. Nothing waiting for review.</p>`}</div>
  <div class="acard"><div class="acard-h"><h2>Site activity</h2><span class="note">events per day · last 14 days</span></div><div class="pd-chart sm" id="admDaily"></div></div></div>`;
}
/* ---------- Doctors ---------- */
function admDoctorsView(){
  const sub=ADM.sub_doc||"all",f=(ADM.f_doc||"").toLowerCase();
  let rows=admDoctors();const cnt=k=>rows.filter(x=>k==="all"||x.lic===k||(k==="hidden"&&!x.pub)).length;
  const list=rows.filter(x=>(sub==="all"||x.lic===sub||(sub==="hidden"&&!x.pub))&&(!f||(x.d.name+" "+SPECS[x.d.spec]+" "+(FACS[x.d.fac]||{}).n).toLowerCase().includes(f)));
  return admHead("Doctors","Add and edit profiles, verify DHA licences, keep documents and publish only verified information.",`<button class="btn blue" type="button" data-act="doc-new">+ Add doctor</button>`)+
  admTabsBar("doc",[["all","All",cnt("all")],["pending","Pending",cnt("pending")],["verified","Verified",cnt("verified")],["unverified","Not verified",cnt("unverified")],["expired","Expired",cnt("expired")],["hidden","Unpublished",cnt("hidden")]],sub)+
  `<div class="atools"><input type="search" placeholder="Search name, specialty or facility" data-filter="doc" value="${admE(ADM.f_doc||"")}" aria-label="Search doctors"></div>
  <div class="atable"><table><thead><tr><th>Doctor</th><th>Specialty</th><th>Facility</th><th>Licence</th><th>Expiry</th><th>Docs</th><th>Status</th><th></th></tr></thead><tbody>${list.map(x=>`<tr><td><b>${admE(x.d.name)}</b>${x.builtin&&!ADM.rec.doctors[x.id]?`<small class="atag">Built-in</small>`:""}</td><td>${admE(SPECS[x.d.spec])}</td><td>${admE((FACS[x.d.fac]||{}).n||"–")}</td><td>${admPill(x.lic,ADM_LIC)}</td><td>${x.exp?`${admDate(x.exp)}${admDays(x.exp)<=60?`<small class="awarn">${admDays(x.exp)<0?"expired":admDays(x.exp)+" days"}</small>`:""}`:"–"}</td><td>${((x.r.docs)||[]).length}</td><td>${x.pub?'<span class="apill s-verified">Published</span>':'<span class="apill s-draft">Hidden</span>'}</td><td class="aright"><button class="alink" type="button" data-act="doc-edit" data-id="${x.id}">Edit</button></td></tr>`).join("")||`<tr><td colspan="8" class="aempty">No doctors match.</td></tr>`}</tbody></table></div>`;
}
function admDocForm(x){
  const d=x?x.d:{},r=x?x.r:{},id=x?x.id:"d-"+Date.now().toString(36);
  const docs=(r.docs||[]).slice();
  const docRows=()=>docs.map((k,j)=>`<div class="adocrow"><span>${ic("book")}</span><div><b>${admE(k.name)}</b><small>${admE(k.type)}${k.url?` · <a href="${admE(k.url)}" target="_blank" rel="noopener">open</a>`:""} · ${admPill(k.status||"pending",[["pending","Pending"],["checked","Checked"],["rejected","Rejected"]])}</small></div><select data-docst="${j}" aria-label="Document status">${[["pending","Pending"],["checked","Checked"],["rejected","Rejected"]].map(o=>`<option value="${o[0]}"${(k.status||"pending")===o[0]?" selected":""}>${o[1]}</option>`).join("")}</select><button type="button" class="alink" data-docdel="${j}">Remove</button></div>`).join("")||`<p class="note">No documents yet.</p>`;
  admOpen(x?"Edit doctor":"Add doctor",`<div class="aform">
   <h3>Profile</h3>
   ${admFld("Full name",admIn("aName",d.name||"",'placeholder="Dr. Full Name"'))}
   <div class="arow2">${admFld("Specialty",admSel("aSpec",SPECS.map((s,i)=>[i,s]),d.spec!=null?d.spec:1))}${admFld("Facility",admSel("aFac",FACS.map((f,i)=>[i,f.n]),d.fac!=null?d.fac:0))}</div>
   <div class="arow2">${admFld("Role or title",admIn("aRole",d.role||"",'placeholder="Consultant Dermatologist"'))}${admFld("Languages",admIn("aLangs",d.langs||"",'placeholder="English, Arabic, Hindi"'))}</div>
   ${admFld("Insurance accepted",admIn("aIns",d.insurance||""))}
   ${admFld("Short bio",`<textarea id="aBio" rows="3">${admE(d.bio||"")}</textarea>`)}
   ${admFld("Public profile link",admIn("aUrl",d.url||"",'type="url" placeholder="https://"'),"Where the details were checked, e.g. the facility's page")}
   <h3>Licence</h3>
   <div class="arow2">${admFld("DHA licence number",admIn("aLic",r.licNo||d.licence||""))}${admFld("Licence expiry",admIn("aExp",r.licExp||"",'type="date"'))}</div>
   ${admFld("Licence status",admSel("aLicSt",ADM_LIC,r.lic||d.lic||"unverified"),"Verify against the official DHA Sheryan register before marking Verified.")}
   <div class="abtns"><a class="btn alt" href="https://www.dha.gov.ae" target="_blank" rel="noopener">Open DHA register</a><button class="btn alt" type="button" id="aVerify">Mark verified today</button></div>
   <h3>Documents</h3><div id="aDocs">${docRows()}</div>
   <div class="adocadd">${admIn("aDocName","",'placeholder="Document name, e.g. DHA licence certificate"')}${admSel("aDocType",[["Licence","Licence"],["Qualification","Qualification"],["ID check","ID check"],["Facility letter","Facility letter"],["Other","Other"]],"Licence")}${admIn("aDocUrl","",'type="url" placeholder="Secure link (optional)"')}<button class="btn alt" type="button" id="aDocAdd">Add</button></div>
   <p class="note">Store links to documents in your secure storage. Don't paste personal ID numbers here.</p>
   <h3>Publishing</h3>
   <label class="acheck"><input type="checkbox" id="aPub" ${r.published===false?"":"checked"}><span>Show this doctor on the website</span></label>
   ${admFld("Note for history (optional)",admIn("aNote","",'placeholder="e.g. Licence checked on Sheryan"'))}
   <div class="abtns sticky"><button class="btn blue" type="button" id="aSave">Save doctor</button>${x&&!x.builtin?`<button class="btn alt adanger" type="button" id="aDel">Delete</button>`:""}</div>
   <h3>Verification history</h3>${admHist(r.hist)}
  </div>`,b=>{
    const redraw=()=>{b.querySelector("#aDocs").innerHTML=docRows();bind()};
    const bind=()=>{b.querySelectorAll("[data-docdel]").forEach(z=>z.onclick=()=>{docs.splice(+z.dataset.docdel,1);redraw()});b.querySelectorAll("[data-docst]").forEach(z=>z.onchange=()=>{docs[+z.dataset.docst].status=z.value})};bind();
    b.querySelector("#aDocAdd").onclick=()=>{const n=admVal("aDocName");if(!n)return;docs.push({name:n,type:admVal("aDocType"),url:admVal("aDocUrl"),status:"pending",at:admNow()});b.querySelector("#aDocName").value="";b.querySelector("#aDocUrl").value="";redraw()};
    b.querySelector("#aVerify").onclick=()=>{b.querySelector("#aLicSt").value="verified";if(!admVal("aNote"))b.querySelector("#aNote").value="Licence verified on DHA register"};
    b.querySelector("#aSave").onclick=async()=>{
      const name=admVal("aName");if(!name){admToast("Enter the doctor's name");return}
      const st=admVal("aLicSt"),pub=b.querySelector("#aPub").checked,hist=(r.hist||[]).slice();
      const prevSt=r.lic||d.lic||"unverified";
      if(!x)hist.push({at:admNow(),action:"Profile created",by:ADM.uid});
      if(st!==prevSt||!x)hist.push({at:admNow(),action:"Licence: "+(ADM_LIC.find(l=>l[0]===st)||[0,st])[1],note:admVal("aNote"),by:ADM.uid});
      else if(admVal("aNote"))hist.push({at:admNow(),action:"Note",note:admVal("aNote"),by:ADM.uid});
      if(x&&(r.published!==false)!==pub)hist.push({at:admNow(),action:pub?"Published":"Unpublished",by:ADM.uid});
      const rec={name,spec:+admVal("aSpec"),fac:+admVal("aFac"),role:admVal("aRole"),langs:admVal("aLangs"),insurance:admVal("aIns"),bio:admVal("aBio"),url:admVal("aUrl"),licNo:admVal("aLic"),licExp:admVal("aExp"),lic:st,docs,published:pub,hist:hist.slice(-50),src:d.src||"",updated:admNow()};
      const ok=await admSet("doctors/"+id,rec);if(!ok){admToast("Couldn't save. Check your edit access.");return}
      ADM.rec.doctors[id]=rec;admApply();admClose();admRender();admToast("Doctor saved");};
    const del=b.querySelector("#aDel");if(del)del.onclick=async()=>{if(!confirm("Delete this doctor? This can't be undone."))return;try{await ADM.db.doc("doctors/"+id).delete()}catch(e){}delete ADM.rec.doctors[id];const k=DOCTORS.findIndex(q=>q._id===id);if(k>=0)DOCTORS[k]._hidden=true;admClose();admRender();admToast("Doctor deleted")};
  });
}
/* ---------- Facilities ---------- */
function admFacView(){
  const f=(ADM.f_fac||"").toLowerCase(),rows=admFacs().filter(x=>!f||(x.f.n+" "+x.f.area).toLowerCase().includes(f));
  return admHead("Facilities","Verify facilities, keep their location and specialties current, and see which doctors practise there.",`<button class="btn blue" type="button" data-act="fac-new">+ Add facility</button>`)+
  `<div class="atools"><input type="search" placeholder="Search facility or area" data-filter="fac" value="${admE(ADM.f_fac||"")}" aria-label="Search facilities"></div>
  <div class="atable"><table><thead><tr><th>Facility</th><th>Location</th><th>Specialties</th><th>Doctors</th><th>Verification</th><th>Status</th><th></th></tr></thead><tbody>${rows.map(x=>`<tr><td><b>${admE(x.f.n)}</b><small class="atag">${admE(x.f.t)}</small></td><td>${admE(x.f.area)}<br><a class="alink" href="https://www.google.com/maps/search/${encodeURIComponent(x.f.n+" "+x.f.area)}" target="_blank" rel="noopener">Map</a></td><td>${(x.f.s||[]).length}</td><td>${DOCTORS.filter(d=>d.fac===x.i&&!d._hidden).length}</td><td>${admPill(x.ver,ADM_LIC)}</td><td>${x.pub?'<span class="apill s-verified">Published</span>':'<span class="apill s-draft">Hidden</span>'}</td><td class="aright"><button class="alink" type="button" data-act="fac-edit" data-id="${x.id}">Edit</button></td></tr>`).join("")}</tbody></table></div>`;
}
function admFacForm(x){
  const f=x?x.f:{s:[]},r=x?x.r:{},id=x?x.id:"f-"+Date.now().toString(36);
  const docs=x?DOCTORS.map((d,i)=>[d,i]).filter(([d])=>d.fac===x.i):[];
  admOpen(x?"Edit facility":"Add facility",`<div class="aform">
   <h3>Facility</h3>
   ${admFld("Name",admIn("fN",f.n||""))}
   <div class="arow2">${admFld("Type",admIn("fT",f.t||"",'placeholder="Hospital, clinic, polyclinic"'))}${admFld("Official website",admIn("fU",f.u||"",'type="url" placeholder="https://"'))}</div>
   <h3>Location</h3>
   ${admFld("Area and address",admIn("fA",f.area||"",'placeholder="Oud Metha, Dubai"'))}
   <p class="note"><a href="https://www.google.com/maps/search/${encodeURIComponent((f.n||"")+" "+(f.area||""))}" target="_blank" rel="noopener">Check on the map</a></p>
   ${admFld("About",`<textarea id="fAb" rows="3">${admE(f.about||"")}</textarea>`)}
   <h3>Specialties</h3>
   <div class="achecks">${SPECS.map((s,i)=>`<label class="acheck"><input type="checkbox" data-fs="${i}" ${(f.s||[]).map(Number).includes(i)?"checked":""}><span>${admE(s)}</span></label>`).join("")}</div>
   <h3>Verification</h3>
   ${admFld("Facility verification",admSel("fV",ADM_LIC,r.ver||f.ver||"unverified"),"Check the facility licence on the DHA register.")}
   ${admFld("Note for history (optional)",admIn("fNote",""))}
   <label class="acheck"><input type="checkbox" id="fPub" ${r.published===false?"":"checked"}><span>Show this facility on the website</span></label>
   <div class="abtns sticky"><button class="btn blue" type="button" id="fSave">Save facility</button></div>
   <h3>Doctors here</h3>${docs.length?`<ul class="alist">${docs.map(([d,i])=>`<li>${admE(d.name)} · ${admE(SPECS[d.spec])}${d._hidden?" (hidden)":""}</li>`).join("")}</ul>`:`<p class="note">No doctors linked yet.</p>`}
   <h3>Verification history</h3>${admHist(r.hist)}
  </div>`,b=>{
    b.querySelector("#fSave").onclick=async()=>{const n=admVal("fN");if(!n){admToast("Enter a name");return}
      const s=[...b.querySelectorAll("[data-fs]")].filter(c=>c.checked).map(c=>+c.dataset.fs);if(!s.length){admToast("Pick at least one specialty");return}
      const v=admVal("fV"),hist=(r.hist||[]).slice();if(v!==(r.ver||f.ver||"unverified")||!x)hist.push({at:admNow(),action:"Verification: "+(ADM_LIC.find(l=>l[0]===v)||[0,v])[1],note:admVal("fNote"),by:ADM.uid});else if(admVal("fNote"))hist.push({at:admNow(),action:"Note",note:admVal("fNote"),by:ADM.uid});
      const rec={n,t:admVal("fT"),u:admVal("fU"),area:admVal("fA"),about:admVal("fAb"),s,ver:v,published:b.querySelector("#fPub").checked,hist:hist.slice(-50),updated:admNow()};
      if(!(await admSet("facilities/"+id,rec))){admToast("Couldn't save");return}ADM.rec.facilities[id]=rec;admApply();admClose();admRender();admToast("Facility saved")};
  });
}
/* ---------- Articles ---------- */
function admArtView(){
  const sub=ADM.sub_art||"all",f=(ADM.f_art||"").toLowerCase(),all=admArts(),cnt=k=>all.filter(a=>k==="all"||a.status===k).length;
  const rows=all.filter(a=>(sub==="all"||a.status===sub)&&(!f||(a.p.t+" "+a.p.c).toLowerCase().includes(f)));
  return admHead("Articles","Every article moves from draft to editorial review, then medical review, before it is published.",`<button class="btn blue" type="button" data-act="art-new">+ New article</button>`)+
  `<div class="apipe">${ADM_ART.map((s,i)=>`<div class="apipe-s s-${s[0]}"><b>${cnt(s[0])}</b><span>${s[1]}</span></div>${i<3?`<i>${ic("arrow")}</i>`:""}`).join("")}</div>`+
  admTabsBar("art",[["all","All",cnt("all")],...ADM_ART.map(s=>[s[0],s[1],cnt(s[0])])],sub)+
  `<div class="atools"><input type="search" placeholder="Search articles" data-filter="art" value="${admE(ADM.f_art||"")}" aria-label="Search articles"></div>
  <div class="atable"><table><thead><tr><th>Title</th><th>Category</th><th>Stage</th><th>Sources</th><th>SEO</th><th>Medical reviewer</th><th></th></tr></thead><tbody>${rows.map(a=>{const seo=admSeoScore(a);return `<tr><td><b>${admE(a.p.t)}</b></td><td>${admE(a.p.c)}</td><td>${admPill(a.status,ADM_ART)}</td><td>${(a.r.sources||[]).length}</td><td><span class="aseo s${seo>=80?"g":seo>=50?"m":"b"}">${seo}</span></td><td>${admE(a.r.medBy||"–")}</td><td class="aright"><button class="alink" type="button" data-act="art-edit" data-id="${a.id}">Edit</button></td></tr>`}).join("")||`<tr><td colspan="7" class="aempty">No articles match.</td></tr>`}</tbody></table></div>`;
}
function admSeoScore(a){const s=(a.r&&a.r.seo)||{},t=s.title||a.p.t||"",d=s.desc||"";let n=0;if(t.length>=30&&t.length<=60)n+=30;else if(t.length)n+=15;if(d.length>=110&&d.length<=160)n+=30;else if(d.length)n+=15;if(s.slug)n+=15;if(s.kw)n+=10;if(((a.r&&a.r.sources)||[]).length)n+=15;return n}
function admArtForm(a){
  const p=a?a.p:{t:"",c:"Protein & Diet",m:3,b:""},r=a?a.r:{},id=a?a.id:"a-"+Date.now().toString(36);
  const status=a?a.status:"draft",src=(r.sources||[]).slice(),seo=Object.assign({title:"",desc:"",slug:"",kw:""},r.seo||{});
  const cats=[...new Set(POSTS.map(x=>x.c))];
  const srcRows=()=>src.map((s,j)=>`<div class="adocrow"><span>${ic("book")}</span><div><b>${admE(s.title)}</b><small>${s.url?`<a href="${admE(s.url)}" target="_blank" rel="noopener">${admE(s.url)}</a>`:""}${s.kind?` · ${admE(s.kind)}`:""}</small></div><button type="button" class="alink" data-srcdel="${j}">Remove</button></div>`).join("")||`<p class="note">Add at least one trusted source before medical review.</p>`;
  const next={draft:["review","Send to editorial review"],review:["medical","Approve for medical review"],medical:["published","Medical sign-off and publish"],published:["draft","Unpublish to draft"]}[status];
  admOpen(a?"Edit article":"New article",`<div class="aform">
   <div class="astage">${ADM_ART.map(s=>`<span class="${s[0]===status?"on":ADM_ART.findIndex(q=>q[0]===s[0])<ADM_ART.findIndex(q=>q[0]===status)?"done":""}">${s[1]}</span>`).join("")}</div>
   <h3>Content</h3>
   ${admFld("Title",admIn("rT",p.t))}
   <div class="arow2">${admFld("Category",admSel("rC",cats.map(c=>[c,c]),p.c))}${admFld("Read time (min)",admIn("rM",p.m,'type="number" min="1" max="30"'))}</div>
   ${admFld("Body",`<textarea id="rB" rows="9">${admE((p.b||"").split("||").join("\n\n"))}</textarea>`,"Separate paragraphs with a blank line. Plain language, no diagnosis, no doses.")}
   <h3>Sources</h3><div id="rSrc">${srcRows()}</div>
   <div class="adocadd">${admIn("rSrcT","",'placeholder="Source title, e.g. WHO: Healthy diet"')}${admSel("rSrcK",[["Official guideline","Official guideline"],["Peer-reviewed study","Peer-reviewed study"],["Government","Government"],["Other","Other"]],"Official guideline")}${admIn("rSrcU","",'type="url" placeholder="https://"')}<button class="btn alt" type="button" id="rSrcAdd">Add</button></div>
   <h3>SEO</h3>
   ${admFld(`Meta title <em id="cT"></em>`,admIn("sT",seo.title||p.t))}
   ${admFld(`Meta description <em id="cD"></em>`,`<textarea id="sD" rows="2">${admE(seo.desc)}</textarea>`)}
   <div class="arow2">${admFld("URL slug",admIn("sS",seo.slug||p.t.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")))}${admFld("Focus keywords",admIn("sK",seo.kw,'placeholder="protein, vegetarian"'))}</div>
   <div class="aserp"><small>Search preview</small><b id="pvT"></b><span id="pvU"></span><p id="pvD"></p></div>
   <h3>Review</h3>
   ${admFld("Medical reviewer",admIn("rMed",r.medBy||"",'placeholder="Dr. Name, specialty"'),"Required before publishing")}
   ${admFld("Review note (optional)",`<textarea id="rNote" rows="2"></textarea>`)}
   <div class="abtns sticky"><button class="btn alt" type="button" id="rSave">Save</button>${next?`<button class="btn blue" type="button" id="rNext">${next[1]}</button>`:""}${status!=="draft"&&status!=="published"?`<button class="btn alt" type="button" id="rBack">Send back to draft</button>`:""}</div>
   <h3>History</h3>${admHist(r.hist)}
  </div>`,b=>{
    const srcDraw=()=>{b.querySelector("#rSrc").innerHTML=srcRows();b.querySelectorAll("[data-srcdel]").forEach(z=>z.onclick=()=>{src.splice(+z.dataset.srcdel,1);srcDraw()})};srcDraw();
    b.querySelector("#rSrcAdd").onclick=()=>{const t=admVal("rSrcT");if(!t)return;src.push({title:t,kind:admVal("rSrcK"),url:admVal("rSrcU")});b.querySelector("#rSrcT").value="";b.querySelector("#rSrcU").value="";srcDraw()};
    const pv=()=>{const t=admVal("sT"),d=admVal("sD");$("#cT").textContent=`${t.length}/60`;$("#cD").textContent=`${d.length}/160`;$("#cT").className=t.length>60?"over":"";$("#cD").className=d.length>160?"over":"";$("#pvT").textContent=(t||"Title")+" | Sehatora Dubai";$("#pvU").textContent="sehatora.ae › blog › "+(admVal("sS")||"slug");$("#pvD").textContent=d||"Add a meta description of about 150 characters."};
    ["sT","sD","sS"].forEach(k=>b.querySelector("#"+k).oninput=pv);pv();
    const save=async(to,label)=>{
      const t=admVal("rT");if(!t){admToast("Add a title");return}
      if(to==="medical"&&!src.length){admToast("Add at least one source first");return}
      if(to==="published"&&!admVal("rMed")){admToast("Add the medical reviewer first");return}
      const hist=(r.hist||[]).slice();if(label)hist.push({at:admNow(),action:label,note:admVal("rNote"),by:ADM.uid});else if(!a)hist.push({at:admNow(),action:"Draft created",by:ADM.uid});
      const rec={t,c:admVal("rC"),m:+admVal("rM")||3,b:admVal("rB").split(/\n\s*\n/).map(x=>x.trim()).filter(Boolean).join("||"),sources:src,seo:{title:admVal("sT")||admVal("rT"),desc:admVal("sD"),slug:admVal("sS"),kw:admVal("sK")},medBy:admVal("rMed"),status:to||status,hist:hist.slice(-60),updated:admNow()};
      if(to==="published")rec.published=admNow();
      if(!(await admSet("articles/"+id,rec))){admToast("Couldn't save");return}ADM.rec.articles[id]=rec;admApply();admClose();admRender();admToast(label||"Article saved")};
    b.querySelector("#rSave").onclick=()=>save(null,a?"Edited":"");
    const nx=b.querySelector("#rNext");if(nx)nx.onclick=()=>save(next[0],next[1]);
    const bk=b.querySelector("#rBack");if(bk)bk.onclick=()=>save("draft","Sent back to draft");
  });
}
/* ---------- AI ---------- */
function admAiView(){
  const sub=ADM.sub_ai||"conv",esc=ALL.sessions.filter(s=>["emergency","crisis","urgent"].includes(s.level)),K=Object.entries(ADM.rec.knowledge);
  const lvl=l=>`<span class="apill l-${l}">${({emergency:"Emergency",crisis:"Crisis",urgent:"Within 24 h",soon:"Book soon",routine:"Self-care"})[l]||l}</span>`;
  let body="";
  if(sub==="conv")body=`<p class="note">AI Health Guide sessions. Only the topic, urgency and chosen answers are logged, never what people typed.</p><div class="atable"><table><thead><tr><th>When</th><th>Topic</th><th>Outcome</th><th>Answers</th><th>Follow-ups</th></tr></thead><tbody>${ALL.sessions.slice(0,200).map(s=>`<tr><td>${admTime(s.at)}</td><td>${admE((HG_TOPICS[s.topic]||{}).label||s.topic)}</td><td>${lvl(s.level)}</td><td class="asmall">${admE((s.said||[]).join(" · "))}</td><td>${s.follow||0}</td></tr>`).join("")||`<tr><td colspan="5" class="aempty">No sessions yet.</td></tr>`}</tbody></table></div>`;
  if(sub==="esc")body=`<p class="note">Sessions that ended with emergency, crisis or 24-hour advice. Review each to check the guide responded safely.</p><div class="atable"><table><thead><tr><th>When</th><th>Topic</th><th>Level</th><th>Red flags picked</th><th>Review</th></tr></thead><tbody>${esc.map(s=>{const rv=ADM.rec.aireview[s.id]||{};return `<tr><td>${admTime(s.at)}</td><td>${admE((HG_TOPICS[s.topic]||{}).label||s.topic||"Typed message")}</td><td>${lvl(s.level)}</td><td class="asmall">${admE((s.flags||[]).join(" · ")||"–")}</td><td>${rv.done?`<span class="apill s-verified">Reviewed</span>`:`<button class="alink" type="button" data-act="rev" data-id="${s.id}">Mark reviewed</button>`}</td></tr>`}).join("")||`<tr><td colspan="5" class="aempty">No escalations.</td></tr>`}</tbody></table></div>`;
  if(sub==="unsafe")body=`<p class="note">AI replies that an automatic check flagged, e.g. sounding like a diagnosis or mentioning a dose. Read each one and mark it reviewed, then tighten the rules or knowledge sources if needed.</p>${ALL.unsafe.map(u=>{const rv=ADM.rec.aireview[u.id]||{};return `<div class="acard aunsafe"><div class="acard-h"><h3>${admE(u.why)}</h3><span class="note">${admTime(u.at)} · ${admE(u.where)}${u.topic?` · ${admE(u.topic)}`:""}</span></div><blockquote>${admE(u.reply)}</blockquote><div class="abtns">${rv.done?`<span class="apill s-verified">Reviewed${rv.note?`: ${admE(rv.note)}`:""}</span>`:`<button class="btn alt" type="button" data-act="rev" data-id="${u.id}">Mark reviewed</button>`}</div></div>`}).join("")||`<p class="aempty">${ic("check")} No flagged replies.</p>`}`;
  if(sub==="know")body=`<div class="abtns" style="margin-bottom:12px"><button class="btn blue" type="button" data-act="kn-new">+ Add source</button></div><p class="note">Active sources are given to the AI Health Guide, so it can point people to them. The site's own ${POSTS.length} guides are always included.</p><div class="atable"><table><thead><tr><th>Source</th><th>Type</th><th>Status</th><th>Added</th><th></th></tr></thead><tbody>${K.map(([id,k])=>`<tr><td><b>${admE(k.title)}</b>${k.url?`<br><a class="alink" href="${admE(k.url)}" target="_blank" rel="noopener">${admE(k.url)}</a>`:""}</td><td>${admE(k.type)}</td><td>${k.active!==false?'<span class="apill s-verified">Active</span>':'<span class="apill s-draft">Paused</span>'}</td><td>${admDate(k.at)}</td><td class="aright"><button class="alink" type="button" data-act="kn-edit" data-id="${id}">Edit</button></td></tr>`).join("")||`<tr><td colspan="5" class="aempty">No extra sources yet.</td></tr>`}</tbody></table></div>`;
  return admHead("AI Health Guide","Watch how the guide is used, review escalations and flagged replies, and control what it knows.")+
  `<div class="akpis">${admKpi("Sessions",ALL.sessions.length)}${admKpi("Escalations",esc.length,`${esc.filter(s=>!(ADM.rec.aireview[s.id]||{}).done).length} not reviewed`,esc.some(s=>!(ADM.rec.aireview[s.id]||{}).done)?"warn":"")}${admKpi("Flagged replies",ALL.unsafe.length,`${ALL.unsafe.filter(u=>!(ADM.rec.aireview[u.id]||{}).done).length} open`,ALL.unsafe.some(u=>!(ADM.rec.aireview[u.id]||{}).done)?"warn":"")}${admKpi("Knowledge sources",K.length+POSTS.length,`${POSTS.length} site guides + ${K.length} added`)}</div>`+
  admTabsBar("ai",[["conv","Conversations",ALL.sessions.length],["esc","Escalations",esc.length],["unsafe","Unsafe responses",ALL.unsafe.length],["know","Knowledge sources",K.length]],sub)+body;
}
function admKnForm(id){
  const k=id?ADM.rec.knowledge[id]:{title:"",url:"",type:"Official guideline",active:true};id=id||"k-"+Date.now().toString(36);
  admOpen(k.title?"Edit source":"Add knowledge source",`<div class="aform">${admFld("Title",admIn("kT",k.title))}${admFld("Link",admIn("kU",k.url,'type="url" placeholder="https://"'))}${admFld("Type",admSel("kY",[["Official guideline","Official guideline"],["Government","Government"],["Peer-reviewed study","Peer-reviewed study"],["Site policy","Site policy"]],k.type))}<label class="acheck"><input type="checkbox" id="kA" ${k.active!==false?"checked":""}><span>Active: the AI can use this source</span></label><div class="abtns sticky"><button class="btn blue" type="button" id="kS">Save source</button></div></div>`,b=>{
    b.querySelector("#kS").onclick=async()=>{const t=admVal("kT");if(!t)return admToast("Add a title");const rec={title:t,url:admVal("kU"),type:admVal("kY"),active:b.querySelector("#kA").checked,at:k.at||admNow()};if(!(await admSet("knowledge/"+id,rec)))return admToast("Couldn't save");ADM.rec.knowledge[id]=rec;admClose();admRender();admToast("Source saved")}});
}
/* ---------- Users ---------- */
function admUsersView(){
  const sub=ADM.sub_usr||"req";let body="";
  if(sub==="acc")body=`<p class="note">People who have used the site while signed in. Names come from your organisation directory.</p><div class="atable"><table><thead><tr><th>Person</th><th>First visit</th><th>Last visit</th><th>Saved doctors</th><th>Requests</th><th>AI sessions</th></tr></thead><tbody>${ALL.members.map(m=>`<tr><td><b data-uname="${admE(m.u)}">Member</b></td><td>${admDate(m.first)}</td><td>${admDate(m.last)}</td><td>${(m.saved||[]).length}</td><td>${ALL.requests.filter(r=>r.u===m.u).length}</td><td>${ALL.sessions.filter(s=>s.u===m.u).length}</td></tr>`).join("")||`<tr><td colspan="6" class="aempty">No accounts yet.</td></tr>`}</tbody></table></div>`;
  if(sub==="saved"){const c={};ALL.members.forEach(m=>(m.saved||[]).forEach(k=>c[k]=(c[k]||0)+1));const rows=Object.entries(c).sort((a,b)=>b[1]-a[1]);
    body=`<p class="note">Which doctors people save most.</p>${admBars(rows.map(([k,n])=>{const i=k.indexOf("b-")===0?+k.slice(2):DOCTORS.findIndex(d=>d._id===k);return [(DOCTORS[i]||{}).name||k,n]}),"saves")}`}
  if(sub==="req")body=`<p class="note">Appointment requests prepared on the site. Contact details are only visible to editors.</p><div class="atable"><table><thead><tr><th>When</th><th>Name</th><th>Phone</th><th>Specialty</th><th>Provider</th><th>Preferred</th><th>Status</th></tr></thead><tbody>${ALL.requests.map(r=>{const st=(ADM.rec.reqstatus[r.id]||{}).status||"new";return `<tr><td>${admTime(r.at)}</td><td><b>${admE(r.name)}</b>${r.note?`<br><small class="asmall">${admE(r.note)}</small>`:""}</td><td><a class="alink" href="tel:${admE(r.phone)}">${admE(r.phone)}</a></td><td>${admE(SPECS[r.spec]||"")}</td><td>${admE((FACS[r.fac]||{}).n||"")}</td><td>${admE(r.date||"Flexible")}</td><td><select data-reqst="${admE(r.id)}" aria-label="Request status">${[["new","New"],["contacted","Contacted"],["booked","Booked"],["closed","Closed"]].map(o=>`<option value="${o[0]}"${st===o[0]?" selected":""}>${o[1]}</option>`).join("")}</select></td></tr>`}).join("")||`<tr><td colspan="7" class="aempty">No requests yet.</td></tr>`}</tbody></table></div>`;
  setTimeout(admUserBind,0);
  return admHead("Users","Accounts, saved doctors and appointment requests.")+
  `<div class="akpis">${admKpi("Accounts",ALL.members.length)}${admKpi("Doctors saved",ALL.members.reduce((n,m)=>n+(m.saved||[]).length,0))}${admKpi("Requests",ALL.requests.length,`${ALL.requests.filter(r=>((ADM.rec.reqstatus[r.id]||{}).status||"new")==="new").length} new`)}</div>`+
  admTabsBar("usr",[["req","Requests",ALL.requests.length],["acc","Accounts",ALL.members.length],["saved","Saved doctors"]],sub)+body;
}
async function admUserBind(){
  document.querySelectorAll("[data-reqst]").forEach(s=>s.onchange=async()=>{const rec={status:s.value,at:admNow(),by:ADM.uid};if(await admSet("reqstatus/"+s.dataset.reqst,rec)){ADM.rec.reqstatus[s.dataset.reqst]=rec;admToast("Request updated");const n=document.querySelector('[data-badge="users"]');if(n){const c=ALL.requests.filter(r=>((ADM.rec.reqstatus[r.id]||{}).status||"new")==="new").length;n.textContent=c?String(c):""}}});
  const els=[...document.querySelectorAll("[data-uname]")];if(!els.length||!ADM.user||!ADM.user.profiles)return;
  try{const ps=await ADM.user.profiles([...new Set(els.map(e=>e.dataset.uname))]);els.forEach(e=>{const p=ps[e.dataset.uname];e.textContent=(p&&p.name)||"Member"})}catch(e){}
}
/* ---------- Analytics ---------- */
function admBars(rows,unit){if(!rows.length)return `<p class="aempty">No data yet.</p>`;const max=Math.max(...rows.map(r=>r[1]));return `<ul class="abars">${rows.slice(0,10).map(r=>`<li><span>${admE(r[0])}</span><div><i style="width:${Math.max(3,r[1]/max*100)}%"></i></div><b>${r[1]}</b></li>`).join("")}</ul>`}
function admCount(filter,keyFn){const c={};ALL.events.filter(filter).forEach(e=>{const k=keyFn(e);if(k==null||k==="")return;c[k]=(c[k]||0)+1});return Object.entries(c).sort((a,b)=>b[1]-a[1])}
function admAnaView(){
  const range=+(ADM.sub_rng||30),since=Date.now()-range*864e5,inR=e=>e.at>=since;
  const q=admCount(e=>inR(e)&&e.t==="search",e=>e.k.toLowerCase().trim());
  const specC={};ALL.events.filter(e=>inR(e)&&(e.t==="spec_search"||e.t==="spec_pick")).forEach(e=>{const n=SPECS[+e.k];if(n)specC[n]=(specC[n]||0)+1});ALL.sessions.filter(s=>s.at>=since&&s.spec!=null).forEach(s=>{const n=SPECS[s.spec];if(n)specC[n]=(specC[n]||0)+1});
  const views=admCount(e=>inR(e)&&e.t==="article_view",e=>e.k),reads=admCount(e=>inR(e)&&e.t==="article_read",e=>e.k),rd=Object.fromEntries(reads);
  const dv=admCount(e=>inR(e)&&e.t==="doctor_view",e=>(DOCTORS[+e.k]||{}).name||e.k),fv=admCount(e=>inR(e)&&e.t==="facility_view",e=>(FACS[+e.k]||{}).n||e.k);
  const req=ALL.requests.filter(r=>r.at>=since),reqS={};req.forEach(r=>{const n=SPECS[r.spec]||"Other";reqS[n]=(reqS[n]||0)+1});
  const aiT={};ALL.sessions.filter(s=>s.at>=since).forEach(s=>{const n=(HG_TOPICS[s.topic]||{}).label||"Typed emergency";aiT[n]=(aiT[n]||0)+1});
  return admHead("Analytics","How people use Sehatora. Counts come from signed-in visitors.",admTabsBar("rng",[["7","7 days"],["30","30 days"],["90","90 days"]],String(range)))+
  `<div class="akpis">${admKpi("Searches",q.reduce((n,x)=>n+x[1],0))}${admKpi("Article views",views.reduce((n,x)=>n+x[1],0),`${reads.reduce((n,x)=>n+x[1],0)} read to the end`)}${admKpi("Doctor profile views",dv.reduce((n,x)=>n+x[1],0))}${admKpi("Appointment requests",req.length)}${admKpi("AI questions",ALL.sessions.filter(s=>s.at>=since).length)}</div>
  <div class="acard" style="margin-bottom:16px"><div class="acard-h"><h2>Daily activity</h2><span class="note">all events · last 14 days</span></div><div class="pd-chart sm" id="admDaily"></div></div>
  <div class="agrid2">
   <div class="acard"><div class="acard-h"><h2>Search queries</h2><span class="note">doctor and guide search</span></div>${admBars(q,"")}</div>
   <div class="acard"><div class="acard-h"><h2>Most searched specialties</h2><span class="note">search, booking and AI outcomes</span></div>${admBars(Object.entries(specC).sort((a,b)=>b[1]-a[1]),"")}</div>
   <div class="acard"><div class="acard-h"><h2>Article engagement</h2><span class="note">views · read-through</span></div>${views.length?`<div class="atable flat"><table><thead><tr><th>Article</th><th>Views</th><th>Read to end</th></tr></thead><tbody>${views.slice(0,10).map(([k,n])=>`<tr><td>${admE((POSTS[+k]||{}).t||k)}</td><td>${n}</td><td>${Math.round((rd[k]||0)/n*100)}%</td></tr>`).join("")}</tbody></table></div>`:`<p class="aempty">No data yet.</p>`}</div>
   <div class="acard"><div class="acard-h"><h2>Doctor and facility views</h2></div>${admBars(dv.concat(fv).sort((a,b)=>b[1]-a[1]),"")}</div>
   <div class="acard"><div class="acard-h"><h2>Appointment requests</h2><span class="note">by specialty</span></div>${admBars(Object.entries(reqS).sort((a,b)=>b[1]-a[1]),"")}</div>
   <div class="acard"><div class="acard-h"><h2>AI questions</h2><span class="note">by topic</span></div>${admBars(Object.entries(aiT).sort((a,b)=>b[1]-a[1]),"")}</div>
  </div>`;
}
/* ---------- actions ---------- */
async function admAct(act,id,btn){
  if(act==="refresh"){btn.disabled=true;await admLoadAll();admRender();admToast("Data refreshed");return}
  if(act==="goto"){ADM.tab=id;document.querySelectorAll("[data-atab]").forEach(x=>x.setAttribute("aria-current",String(x.dataset.atab===id)));admRender();return}
  if(act==="doc-new")return admDocForm(null);
  if(act==="doc-edit")return admDocForm(admDoctors().find(x=>x.id===id));
  if(act==="fac-new")return admFacForm(null);
  if(act==="fac-edit")return admFacForm(admFacs().find(x=>x.id===id));
  if(act==="art-new")return admArtForm(null);
  if(act==="art-edit")return admArtForm(admArts().find(x=>x.id===id));
  if(act==="kn-new")return admKnForm(null);
  if(act==="kn-edit")return admKnForm(id);
  if(act==="rev"){const note=prompt("Review note (optional)")||"";const rec={done:true,note,at:admNow(),by:ADM.uid};if(await admSet("aireview/"+id,rec)){ADM.rec.aireview[id]=rec;admRender();admToast("Marked reviewed")}}
}

function admArtMeta(i){const p=POSTS[i];if(!p)return "";const r=(ADM.rec.articles||{})[p._id||("b-"+i)];if(!r)return "";
 return `<div class="art-meta">${r.medBy?`<span class="rv-by">${ic("shield")} Medically reviewed by ${admE(r.medBy)}${r.published?` · ${admDate(r.published)}`:""}</span>`:""}${(r.sources||[]).length?`<div><b>Sources</b><ol>${r.sources.map(x=>`<li>${x.url?`<a href="${admE(x.url)}" target="_blank" rel="noopener">${admE(x.title)}</a>`:admE(x.title)}${x.kind?` <span class="note">(${admE(x.kind)})</span>`:""}</li>`).join("")}</ol></div>`:""}</div>`}
function admLogRequest(r){if(!ADM.uid)return;r.id=ADM.uid.slice(0,6)+"-"+Date.now().toString(36);r.at=Date.now();ADM.own.requests.push(r);ADM.own.requests=ADM.own.requests.slice(-50);admSet("requests/"+ADM.uid,{items:ADM.own.requests});evLog("request",r.spec)}
addEventListener("hashchange",()=>{const m=location.hash.match(/^#\/blog\/(\d+)/);if(!m)return;const p=POSTS[+m[1]];if(p&&p.seo&&p.seo.title){document.title=p.seo.title+" | Sehatora Dubai"}const md=document.querySelector('meta[name="description"]');if(md&&p&&p.seo&&p.seo.desc)md.setAttribute("content",p.seo.desc)});

document.addEventListener("input",e=>{const t=e.target;if(!t)return;
 if(t.id==="blogQ"){if(typeof initBlog==="function"){const g=$("#blogGrid");clearTimeout(t._t);t._t=setTimeout(()=>{const bq=t.value.trim().toLowerCase();g.innerHTML=POSTS.map((p,i)=>(!p._hidden&&(curCat==="All"||p.c===curCat)&&(!bq||(p.t+" "+p.c+" "+p.b).toLowerCase().includes(bq)))?postCard(i):"").join("")||`<p class="note">No guides match. Try another word.</p>`;observe();if(bq.length>2){clearTimeout(t._l);t._l=setTimeout(()=>evLog("search",bq,{w:"guides"}),1200)}},120)}}
 if(t.id==="docQ"){const sp=$("#spec");if(sp)sp.dispatchEvent(new Event("change"));const q=t.value.trim().toLowerCase();if(q.length>2){clearTimeout(t._l);t._l=setTimeout(()=>evLog("search",q,{w:"doctors"}),1200)}}
});
